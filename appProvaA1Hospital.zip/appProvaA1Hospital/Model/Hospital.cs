﻿using SQLite;

namespace appClasseHospitalBD.Model
{
    [Table("Hospital")]
    public class Hospital
    {
        // Identificador único da Hospital (Chave Primária com Auto Incremento)
        [PrimaryKey, AutoIncrement, Unique, NotNull]
        public int hosID { get; set; }

        // Nome da Hospital (Máximo 1000 caracteres, permite nulo)
        [MaxLength(1000)]
        public string? hosNome { get; set; }

        // Endereço da Hospital
        // Nota: O atributo [MaxLength] foi removido aqui pois ele só se aplica a strings/arrays, não a inteiros.
        [MaxLength(1000)]
        public string? hosEndereco { get; set; }
    }
}
